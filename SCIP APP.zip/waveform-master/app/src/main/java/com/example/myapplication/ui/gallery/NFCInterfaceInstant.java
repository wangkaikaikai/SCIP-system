package com.example.myapplication.ui.gallery;

import com.example.myapplication.ui.home.HomeInterfaceInstant;
import com.example.myapplication.ui.home.HomeUpdateListener;

public class NFCInterfaceInstant {
    private NFCInterface listener;
    private static NFCInterfaceInstant INSTANCE;
    public synchronized static NFCInterfaceInstant getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new NFCInterfaceInstant();
        }
        return INSTANCE;
    }
    public void init(NFCInterface listener) {
        this.listener = listener;
    }
    public void getNFC_DATA(){
        listener.getNFC_DATA();
    }
}
