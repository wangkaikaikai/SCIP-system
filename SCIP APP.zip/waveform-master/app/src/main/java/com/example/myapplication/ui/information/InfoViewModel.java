package com.example.myapplication.ui.information;

import androidx.lifecycle.ViewModel;

public class InfoViewModel extends ViewModel {
}
