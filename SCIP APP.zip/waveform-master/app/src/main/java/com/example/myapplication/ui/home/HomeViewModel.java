package com.example.myapplication.ui.home;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class HomeViewModel extends ViewModel {
    /**
     * Hr:心率
     */
    private final MutableLiveData<String> Hr = new MutableLiveData<>();
    public LiveData<String> getHr() {
        return Hr;
    }
    public void updateHr(String newText) {
        Hr.setValue(newText);
    }
    /**
     * TempC:温度
     */
    private final MutableLiveData<String> TempC = new MutableLiveData<>();
    public LiveData<String> getTempC() {
        return TempC;
    }
    public void updateTempC(String newText) {
        TempC.setValue(newText);
    }
    /**
     * Steps:步数
     */
    private final MutableLiveData<String> Steps = new MutableLiveData<>();
    public LiveData<String> getSteps() {
        return Steps;
    }
    public void updateSteps(String newText) {
        Steps.setValue(newText);
    }
    /**
     * flag:蓝牙启停flag
     */
    private final MutableLiveData<Boolean> flag = new MutableLiveData<>(false);;;
    public MutableLiveData<Boolean> getFlag() {
        return flag;
    }
    public void updateFlag(Boolean bool) {
        flag.setValue(bool);
    }
}