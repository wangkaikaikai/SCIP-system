package com.example.myapplication.ui.home;

import com.github.mikephil.charting.charts.LineChart;

public interface HomeUpdateListener {
    void onUpdateHrRequested(String newText);
    void onUpdateTempCRequested(String newText);
    void onUpdateStepsRequested(String newText);
    void onUpdateFlagRequested(Boolean bool);

    Boolean get_flag();
    LineChart get_ChartECG();
    LineChart get_chartACC();
    LineChart get_chartBreath();
    LineChart get_chartPPG();
}
