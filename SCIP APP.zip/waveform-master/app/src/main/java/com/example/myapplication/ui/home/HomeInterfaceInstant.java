package com.example.myapplication.ui.home;

import com.github.mikephil.charting.charts.LineChart;

public class HomeInterfaceInstant {
    private HomeUpdateListener listener;
    private static HomeInterfaceInstant INSTANCE;
    public synchronized static HomeInterfaceInstant getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new HomeInterfaceInstant();
        }
        return INSTANCE;
    }
    public void init(HomeUpdateListener listener) {
        this.listener = listener;
    }

    public void onUpdateHrRequested(String newText) {
        listener.onUpdateHrRequested(newText);
    }

    public void onUpdateTempCRequested(String newText) {
        listener.onUpdateTempCRequested(newText);
    }

    public void onUpdateStepsRequested(String newText) {
        listener.onUpdateStepsRequested(newText);
    }
    public void onUpdateFlagRequested(Boolean bool){
        listener.onUpdateFlagRequested(bool);
    }
    public Boolean get_flag(){
        return listener.get_flag();
    }
    public LineChart get_ChartECG(){
        return listener.get_ChartECG();
    }
    public LineChart get_chartACC(){
        return listener.get_chartACC();
    }
    public LineChart get_chartBreath(){
        return listener.get_chartBreath();
    }
    public LineChart get_chartPPG(){
        return listener.get_chartPPG();
    }
}
