package com.example.myapplication.ui.information;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.example.myapplication.MainActivity;
import com.example.myapplication.R;
import com.example.myapplication.databinding.FragmentInfoBinding;
import com.example.myapplication.databinding.FragmentSlideshowBinding;
import com.example.myapplication.ui.slideshow.SlideshowViewModel;


public class InfoFragment extends Fragment {

    private FragmentInfoBinding binding;
    /**
     * 受访者信息
     */
    private EditText etName, etAge, etHeight, etWeight;
    private RadioGroup rgGender;

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        InfoViewModel infoViewModel = new ViewModelProvider(this).get(InfoViewModel.class);

        binding = FragmentInfoBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        // 初始化视图
        etName = binding.etName;
        etAge = binding.etAge;
        etHeight = binding.etHeight;
        etWeight = binding.etWeight;
        rgGender = binding.rgGender;

        Button btnSave = binding.btnSave;
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 在 nav_info Fragment 里提交修改后：
                saveRespondentInfo();
                ((MainActivity) requireActivity()).updateRespondentInfo();
                Navigation.findNavController(requireView()).navigateUp();
            }
        });
        getRespondentInfo();

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
    private void saveRespondentInfo() {
        String name = etName.getText().toString();
        String ageStr = etAge.getText().toString();
        String heightStr = etHeight.getText().toString();
        String weightStr = etWeight.getText().toString();
        int selectedId = rgGender.getCheckedRadioButtonId();
        String gender = "";
        if (selectedId == R.id.rb_male) {
            gender = "男";
        } else if (selectedId == R.id.rb_female) {
            gender = "女";
        }

        // 验证输入
        if (name.isEmpty() || ageStr.isEmpty() || heightStr.isEmpty() || weightStr.isEmpty() || gender.isEmpty()) {
            Toast.makeText(getActivity(), "请填写所有字段", Toast.LENGTH_SHORT).show();
            return;
        }

        SharedPreferences prefs = getActivity().getSharedPreferences("RespondentInfo", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("name", name);
        editor.putString("gender", gender);
        editor.putInt("age", Integer.parseInt(ageStr));
        editor.putInt("height", Integer.parseInt(heightStr));
        editor.putInt("weight", Integer.parseInt(weightStr));
        editor.apply();
        Toast.makeText(getActivity(), "信息已保存", Toast.LENGTH_SHORT).show();
    }

    public void getRespondentInfo(){
        // 加载已保存的数据
        SharedPreferences prefs = getActivity().getSharedPreferences(getString(R.string.SharedPreferences), Context.MODE_PRIVATE);
        etName.setText(prefs.getString(getString(R.string.name), ""));
        etAge.setText(String.valueOf(prefs.getInt(getString(R.string.age), 0)));
        etHeight.setText(String.valueOf(prefs.getInt(getString(R.string.height), 0)));
        etWeight.setText(String.valueOf(prefs.getInt(getString(R.string.weight), 0)));
        String gender = prefs.getString(getString(R.string.gender), "");

        if (gender.equals("男")) {
            rgGender.check(R.id.rb_male);
        } else if (gender.equals("女")) {
            rgGender.check(R.id.rb_female);
        }
    }
}