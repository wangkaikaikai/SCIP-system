package com.example.myapplication.peripheral;

public class DataUtils {
    /**
     * byte数组转string
     * @param bytes
     * @return
     */
    public static String bytesToHexStr(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02x", b)); // %02x 表示两位小写十六进制
        }
        return sb.toString();
    }
    public static float bytes2Float(byte[] arr) {
        int accum = 0;
        accum = accum|(arr[0] & 0xff) << 0;
        accum = accum|(arr[1] & 0xff) << 8;
        accum = accum|(arr[2] & 0xff) << 16;
        accum = accum|(arr[3] & 0xff) << 24;
        return Float.intBitsToFloat(accum);
    }

    public static long bytesToUnsignedInt(byte[] bytes) {
        if (bytes.length != 4) {
            throw new IllegalArgumentException("Byte array must be exactly 4 bytes");
        }
        // 小端模式：最低有效字节在最前
        return ((long)(bytes[3] & 0xFF) << 24) |
                ((long)(bytes[2] & 0xFF) << 16) |
                ((long)(bytes[1] & 0xFF) << 8)  |
                ((long)(bytes[0] & 0xFF));
    }
    public static float[] doubleArrayToFloatArray(double[] doubleArray) {
        if (doubleArray == null) {
            return null;
        }
        float[] floatArray = new float[doubleArray.length];
        for (int i = 0; i < doubleArray.length; i++) {
            floatArray[i] = (float) doubleArray[i];
        }
        return floatArray;
    }
}
