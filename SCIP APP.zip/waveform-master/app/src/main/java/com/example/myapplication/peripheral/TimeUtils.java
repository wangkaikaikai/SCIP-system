package com.example.myapplication.peripheral;

import android.os.Build;

import androidx.annotation.RequiresApi;

import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class TimeUtils {

    /**
     * 获取当前标准时间（本地时区）
     * @return 格式化的时间字符串 "yyyy-MM-dd HH:mm:ss"
     */
    public static String getCurrentTime() {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy年MM月dd日HH时mm分ss秒", Locale.getDefault());
            sdf.setTimeZone(TimeZone.getTimeZone("Asia/Shanghai")); // 中国标准时间（东八区）
            return sdf.format(new Date());
        } catch (Exception e) {
            e.printStackTrace();
            return "1970-01-01 00:00:00"; // 默认返回值
        }
    }

    /**
     * 获取当前UTC时间
     * @return 格式化的UTC时间字符串 "yyyy-MM-dd HH:mm:ss"
     */
    public static String getMillisecond() {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy年MM月dd日HH时mm分ss秒SSS", Locale.getDefault());
            sdf.setTimeZone(TimeZone.getTimeZone("Asia/Shanghai")); // 中国标准时间（东八区）
            return sdf.format(new Date());
        } catch (Exception e) {
            e.printStackTrace();
            return "1970-01-01 00:00:00";
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public static String convertSecondsToDateTime(long secondsTimestamp) {
        // 将秒级时间戳转为毫秒级
        long millisecondsTimestamp = secondsTimestamp * 1000L;

        // 使用Java 8的日期时间API
        Instant instant = Instant.ofEpochMilli(millisecondsTimestamp);
        LocalDateTime dateTime = LocalDateTime.ofInstant(instant, ZoneId.systemDefault());

        // 定义标准时间格式
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        // 格式化输出
        return dateTime.format(formatter);
    }
    @RequiresApi(api = Build.VERSION_CODES.O)
    public static String convertSecondsToDateTime(long secondsTimestamp,int index) {
        // 将秒级时间戳转为毫秒级
        long millisecondsTimestamp = secondsTimestamp * 1000L;

        // 使用Java 8的日期时间API
        Instant instant = Instant.ofEpochMilli(millisecondsTimestamp);
        LocalDateTime dateTime = LocalDateTime.ofInstant(instant, ZoneId.systemDefault());

        // 定义标准时间格式
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy_MM_dd  HH_mm_ss");

        // 格式化输出
        return dateTime.format(formatter);
    }

}