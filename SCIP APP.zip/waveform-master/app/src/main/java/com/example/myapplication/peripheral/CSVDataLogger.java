package com.example.myapplication.peripheral;

import android.os.Environment;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class CSVDataLogger {
    private static final String DEFAULT_FILE_NAME = "default_log";
    private static final int DEFAULT_BATCH_SIZE = 1000;

    private String fileName;
    private int batchSize;
    private String dateFormat;
    private File csvFile;
    private BufferedWriter writer;

    private final LinkedBlockingQueue<String> queue = new LinkedBlockingQueue<>();
    private Thread writerThread;
    private ScheduledExecutorService scheduler;

    /**
     * 构造函数使用默认文件名和批量大小
     */
    public CSVDataLogger() {
        this(DEFAULT_FILE_NAME, DEFAULT_BATCH_SIZE,"");
    }

    public CSVDataLogger(String fileName, int batchSize, String header) {
        this.fileName = fileName;
        this.batchSize = batchSize;
        this.dateFormat = TimeUtils.getCurrentTime();
        initCSVFile(header);
        startWriterThread();
        startFlushScheduler();
    }

    private void initCSVFile(String header) {
        try {
            File directory = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "MyAppData");
            if (!directory.exists()) directory.mkdirs();

            csvFile = new File(directory, fileName + "_" + dateFormat + ".csv");
            writer = new BufferedWriter(new FileWriter(csvFile, true));
            if (!csvFile.exists() || csvFile.length() == 0) {
                writer.write(header);
                writer.newLine();
                writer.flush();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void startWriterThread() {
        writerThread = new Thread(() -> {
            try {
                while (!Thread.currentThread().isInterrupted()) {
                    String line = queue.take(); // 阻塞等待数据
                    writer.write(line);
                    writer.newLine();
                }
            } catch (IOException | InterruptedException e) {
                e.printStackTrace();
            }
        });
        writerThread.setDaemon(true); // 守护线程随进程结束
        writerThread.start();
    }

    private void startFlushScheduler() {
        scheduler = Executors.newScheduledThreadPool(1);
        scheduler.scheduleAtFixedRate(this::flush, 1, 1, TimeUnit.SECONDS);
    }

    // --- 数据添加方法 ---
    public void addData(float[] data) {
        String timestamp = TimeUtils.getMillisecond();
        for (float v : data) {
            queue.offer(timestamp + "," + v);
        }
    }

    public void addData(float[] data, float[] data1) {
        String timestamp = TimeUtils.getMillisecond();
        for (int i = 0; i < data.length; i++) {
            queue.offer(timestamp + "," + data[i] + "," + data1[i]);
        }
    }

    public void addData(float[] data, float[] data1, float[] data2) {
        String timestamp = TimeUtils.getMillisecond();
        for (int i = 0; i < data.length; i++) {
            queue.offer(timestamp + "," + data[i] + "," + data1[i] + "," + data2[i]);
        }
    }

    public void addData(float[] data, float[] data1, float[] data2, float[] data3) {
        String timestamp = TimeUtils.getMillisecond();
        for (int i = 0; i < data.length; i++) {
            queue.offer(timestamp + "," + data[i] + "," + data1[i] + "," + data2[i] + "," + data3[i]);
        }
    }

    public void addData(String[] data) {
        StringBuilder sb = new StringBuilder();
        for (String s : data) {
            sb.append(s).append(",");
        }
        if (sb.length() > 0) sb.setLength(sb.length() - 1); // 去掉最后逗号
        queue.offer(sb.toString());
    }

    // --- 强制 flush ---
    public void flush() {
        try {
            synchronized (writer) {
                writer.flush();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // --- 关闭 logger ---
    public void close() {
        if (scheduler != null) scheduler.shutdownNow();
        if (writerThread != null) writerThread.interrupt();
        flush();
        try {
            if (writer != null) writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String getCSVFilePath() {
        return csvFile != null ? csvFile.getPath() : null;
    }
}
