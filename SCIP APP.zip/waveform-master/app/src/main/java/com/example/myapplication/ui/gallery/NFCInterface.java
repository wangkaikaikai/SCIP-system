package com.example.myapplication.ui.gallery;

public interface NFCInterface {
    void getNFC_DATA();
}
