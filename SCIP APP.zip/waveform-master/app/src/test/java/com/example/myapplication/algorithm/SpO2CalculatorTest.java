package com.example.myapplication.algorithm;

import junit.framework.TestCase;
public class SpO2CalculatorTest extends TestCase {

    public void testTest1() {

    }
}