#ifndef _MAIN_H
#define _MAIN_H
#include <Arduino.h>

#pragma pack(1)
typedef enum {
    BLE_SEND_ECG_DATA,//ECG发送程序
	BLE_SEND_ACC_DATA,
	BLE_SEND_HR_DATA,
	MSG_REC_ACC_DATA,
} sys_event_type_t;

typedef struct {
	sys_event_type_t type;
    float* Fdata;
	unsigned int heartRate;//心率
	unsigned int RRinterval;//心率间隔
	uint8_t* ecgdata;
	uint16_t size;
} sys_event_t;

typedef struct
{
    float     acc_x;
    float     acc_y;
    float     acc_z;
}ACC_DATA_T;
#pragma pack()

#endif