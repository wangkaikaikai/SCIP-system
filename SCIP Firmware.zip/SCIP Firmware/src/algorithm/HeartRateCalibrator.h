#ifndef _HeartRateCalibrator_H
#define _HeartRateCalibrator_H

#define DEFAULT_MIN_HEART_RATE 50
#define DEFAULT_MAX_HEART_RATE 210
#define DEFAULT_MAX_ALLOWED_CHANGE 3
#define RELAXED_MAX_ALLOWED_CHANGE 12
#define SMOOTHING_WINDOW_SIZE 3

typedef struct {
    int heartRateHistory[SMOOTHING_WINDOW_SIZE];
    int historyIndex;
    int historyCount;
    int consecutiveOverThreshold;
    int currentMaxAllowedChange;
    int zeroCount; // 记录连续0值的计数器
} HeartRateCalibrator;


HeartRateCalibrator* HeartRateCalibrator_getInstance();
void addToHistory(HeartRateCalibrator* calibrator, int heartRate);
int getLastHeartRate(HeartRateCalibrator* calibrator) ;
int calculateSmoothedValue(HeartRateCalibrator* calibrator);
int HeartRateCalibrator_calibrate(HeartRateCalibrator* calibrator, int rawHeartRate) ;
void HeartRateCalibrator_reset(HeartRateCalibrator* calibrator);
int HeartRateCalibrator_getCurrentMaxAllowedChange(HeartRateCalibrator* calibrator);
void HeartRateCalibrator_destroy(HeartRateCalibrator* calibrator);

#endif
