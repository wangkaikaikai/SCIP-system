#ifndef _FILTER_H_
#define _FILTER_H_
#define PRECISION double

PRECISION filter(PRECISION signal);
PRECISION filter0(PRECISION signal);
PRECISION filter1(PRECISION signal);
PRECISION filter2(PRECISION signal);

#endif
