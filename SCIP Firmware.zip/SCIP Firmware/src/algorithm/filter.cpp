#include "filter.h"

#define filter_len  9
PRECISION b[filter_len] = {0.020341578860304,0,-0.081366315441214,0,0.122049473161821,0,-0.081366315441214,0, 0.020341578860304};
PRECISION a[filter_len] = {1.000000000000000,  -5.466302735155168,  13.064228777810712, -18.028392055417115,  15.878951945012863,  -9.184407175091327,   3.392535546629019,
            -0.726948933555153,   0.070334637496954};
static PRECISION state_signal[filter_len];
static PRECISION state_result[filter_len];
static PRECISION FOut_ECG = 0;
PRECISION filter(PRECISION signal)
{
        int j = 0;
        state_signal[0] = signal;
        FOut_ECG = 0;

        for (j = 0; j < filter_len; j++)
        {
            FOut_ECG += b[j] * state_signal[j];
        }
        for (j = 1; j < filter_len; j++)
        {
            FOut_ECG -= a[j] * state_result[j - 1];
        }
        for (j = filter_len - 1; j > 0; j--)
        {
            state_signal[j] = state_signal[j - 1];
        }
        for (j = filter_len - 1; j > 0; j--)
        {
            state_result[j] = state_result[j - 1];
        }
        state_result[0] = FOut_ECG;
        return FOut_ECG;
}


#define filter0_len  3
PRECISION b0[filter0_len] = {0.991360034450988, -1.982720068901975, 0.991360034450988};
PRECISION a0[filter0_len] = {1.0, -1.982645418504117, 0.982794719299834};

static PRECISION state_signal0[filter0_len];
static PRECISION state_result0[filter0_len];
static PRECISION FOut0_ECG = 0;
PRECISION filter0(PRECISION signal)
{
    int j = 0;
    state_signal0[0] = signal;
    FOut0_ECG = 0;

    for (j = 0; j < filter0_len; j++)
    {
        FOut0_ECG += b0[j] * state_signal0[j];
    }
    for (j = 1; j < filter0_len; j++)
    {
        FOut0_ECG -= a0[j] * state_result0[j - 1];
    }
    for (j = filter0_len - 1; j > 0; j--)
    {
        state_signal0[j] = state_signal0[j - 1];
    }
    for (j = filter0_len - 1; j > 0; j--)
    {
        state_result0[j] = state_result0[j - 1];
    }
    state_result0[0] = FOut0_ECG;
    return FOut0_ECG;
}

#define filter1_len  5
PRECISION b1[filter1_len] = {0.965885289744070, -1.301979946640172, 2.370526557928993, -1.301979946640172, 0.965885289744070};
PRECISION a1[filter1_len] = {1.0, -1.324580361848915, 2.369362405660521, -1.279379531431428, 0.932934731756612};

static PRECISION state_signal1[filter1_len];
static PRECISION state_result1[filter1_len];
static PRECISION FOut1_ECG = 0;
PRECISION filter1(PRECISION signal)
{
    int j = 0;
    state_signal1[0] = signal;
    FOut1_ECG = 0;

    for (j = 0; j < filter1_len; j++)
    {
        FOut1_ECG += b1[j] * state_signal1[j];
    }
    for (j = 1; j < filter1_len; j++)
    {
        FOut1_ECG -= a1[j] * state_result1[j - 1];
    }
    for (j = filter1_len - 1; j > 0; j--)
    {
        state_signal1[j] = state_signal1[j - 1];
    }
    for (j = filter1_len - 1; j > 0; j--)
    {
        state_result1[j] = state_result1[j - 1];
    }
    state_result1[0] = FOut1_ECG;
    //FOut1_ECG /= a1[0];
    return FOut1_ECG;
    }

#define filter2_len 3
PRECISION b2[filter2_len] = {0.087821281759137, 0.175642563518274, 0.087821281759137};
PRECISION a2[filter2_len] = {1.0, -1.004772209703067, 0.356057336739615};

static PRECISION state_signal2[filter2_len];
static PRECISION state_result2[filter2_len];
static PRECISION FOut2_ECG = 0;
PRECISION filter2(PRECISION signal)
{
    int j = 0;
    state_signal2[0] = signal;
    FOut2_ECG = 0;

    for (j = 0; j < filter2_len; j++)
    {
        FOut2_ECG += b2[j] * state_signal2[j];
    }
    for (j = 1; j < filter2_len; j++)
    {
        FOut2_ECG -= a2[j] * state_result2[j - 1];
    }
    for (j = filter2_len - 1; j > 0; j--)
    {
        state_signal2[j] = state_signal2[j - 1];
    }
    for (j = filter2_len - 1; j > 0; j--)
    {
        state_result2[j] = state_result2[j - 1];
    }
    state_result2[0] = FOut2_ECG;
    //FOut1_ECG /= a1[0];
    return FOut2_ECG;
}

