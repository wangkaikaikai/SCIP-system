#include <SPI.h>
#include <Wire.h>
#include <driver/timer.h>
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>
#include <Arduino.h>
#include <sstream>
#include <string>
#include "algorithm/filter.h"
#include "algorithm/RespiratoryRateCalculator.h"
#include "algorithm/HeartRateCalibrator.h"
#include "main.h"

void task_message_send(sys_event_t event);
void usr_ble_ecg_data_send(uint8_t* ecgdata, uint16_t size);
void usr_ble_acc_data_send(uint8_t* fdata, uint16_t size);

static UBaseType_t myUBaseType;
MAX30003 max30003;
LIS2DH12 accel; // Create instance
RespiratoryRateCalculator& calculator = RespiratoryRateCalculator::getInstance();
HeartRateCalibrator* calibrator = HeartRateCalibrator_getInstance();
uint32_t resp_sample_index = 0;

static SemaphoreHandle_t MuxSem_Handle = xSemaphoreCreateMutex();
static QueueHandle_t sys_queue;
static sys_event_t usr_ecg_event;
static sys_event_t usr_acc_event;

uint8_t txValue = 0;
BLEServer *pServer = NULL;					 // BLEServer指针 pServer
BLECharacteristic *pTxCharacteristic = NULL; // BLECharacteristic指针 pTxCharacteristic
BLECharacteristic *pTxCharacteristic_2 = NULL; // BLECharacteristic指针 pTxCharacteristic_2
BLECharacteristic *pTxCharacteristic_3 = NULL; 
BLECharacteristic *pTxCharacteristic_4 = NULL; 
bool deviceConnected = false;				 // 本次连接状态
bool oldDeviceConnected = false;			 // 上次连接状态

// See the following for generating UUIDs: https://www.uuidgenerator.net/
#define SERVICE_UUID "8b3bd5f2-d9f6-4627-8d4a-95528b20f5ed" // UART service UUID
#define CHARACTERISTIC_UUID_RX "33bd79a8-fc9a-4201-b682-2b029130b90e"
#define CHARACTERISTIC_UUID_TX "c48d0417-de7a-41ef-b34c-1c1f0202a53f"
#define CHARACTERISTIC_UUID_TX_2 "c48d0418-de7a-41ef-b34c-1c1f0202a53f"
#define CHARACTERISTIC_UUID_TX_3 "c48d0419-de7a-41ef-b34c-1c1f0202a53f"
#define CHARACTERISTIC_UUID_TX_4 "c48d0420-de7a-41ef-b34c-1c1f0202a53f"

class MyServerCallbacks : public BLEServerCallbacks
{
	void onConnect(BLEServer *pServer)
	{
		deviceConnected = true;
	};

	void onDisconnect(BLEServer *pServer)
	{
		deviceConnected = false;
	}
};

class MyCallbacks : public BLECharacteristicCallbacks
{
	void onWrite(BLECharacteristic *pCharacteristic)
	{
		std::string rxValue = pCharacteristic->getValue(); // 接收信息

		if (rxValue.length() > 0)
		{ // 向串口输出收到的值
			Serial.print("RX: ");
			for (int i = 0; i < rxValue.length(); i++)
				Serial.print(rxValue[i]);
			Serial.println();

		}
	}
};

void BLE_Init(void)
{
	// 创建一个 BLE 设备
	BLEDevice::init("UART_BLE");

	// 创建一个 BLE 服务
	pServer = BLEDevice::createServer();
	pServer->setCallbacks(new MyServerCallbacks()); // 设置回调
	BLEService *pService = pServer->createService(SERVICE_UUID);

	// 创建一个 BLE 特征
	pTxCharacteristic = pService->createCharacteristic(CHARACTERISTIC_UUID_TX, BLECharacteristic::PROPERTY_NOTIFY);//ecg数据
	pTxCharacteristic->addDescriptor(new BLE2902());
	pTxCharacteristic_2 = pService->createCharacteristic(CHARACTERISTIC_UUID_TX_2, BLECharacteristic::PROPERTY_NOTIFY);//心率、加速度、温度
	pTxCharacteristic_2->addDescriptor(new BLE2902());
	pTxCharacteristic_3 = pService->createCharacteristic(CHARACTERISTIC_UUID_TX_3, BLECharacteristic::PROPERTY_NOTIFY);//心率、加速度、温度
	pTxCharacteristic_3->addDescriptor(new BLE2902());
	pTxCharacteristic_4 = pService->createCharacteristic(CHARACTERISTIC_UUID_TX_4, BLECharacteristic::PROPERTY_NOTIFY);//心率、加速度、温度
	pTxCharacteristic_4->addDescriptor(new BLE2902());
	BLECharacteristic *pRxCharacteristic = pService->createCharacteristic(CHARACTERISTIC_UUID_RX, BLECharacteristic::PROPERTY_WRITE);
	pRxCharacteristic->setCallbacks(new MyCallbacks()); // 设置回调

	pService->start();					// 开始服务
	pServer->getAdvertising()->start(); // 开始广播
	Serial.println(" 等待一个客户端连接，且发送通知... ");
}

void BLE_Connection_Status(void)
{
	// deviceConnected 已连接
	if (deviceConnected)
	{
		#if 0
		pTxCharacteristic->setValue(&txValue, 1); // 设置要发送的值为1
		pTxCharacteristic->notify();			  // 广播
		txValue++;								  // 指针地址自加1
												  // delay(2000);                           // 如果有太多包要发送，蓝牙会堵塞
		#endif
	}
	// disconnecting  断开连接
	if (!deviceConnected && oldDeviceConnected)
	{
		delay(500);					 // 留时间给蓝牙缓冲
		pServer->startAdvertising(); // 重新广播
		Serial.println(" 开始广播 ");
		oldDeviceConnected = deviceConnected;
	}

	// connecting  正在连接
	if (deviceConnected && !oldDeviceConnected)
	{
		// do stuff here on connecting
		oldDeviceConnected = deviceConnected;
	}
}

void max30003_Init(void)
{
	pinMode(MAX30003_CS_PIN, OUTPUT);
	digitalWrite(MAX30003_CS_PIN, HIGH); // disable device

	// SPI.begin(18, 19, 23, 5); //VSPI
	SPI.begin();
	SPI.setBitOrder(MSBFIRST);
	SPI.setDataMode(SPI_MODE0);

	bool ret = max30003.max30003ReadInfo();
	if (ret)
	{
		Serial.println("Max30003 read ID Success");
	}
	else
	{
		while (!ret)
		{
			// stay here untill the issue is fixed.
			ret = max30003.max30003ReadInfo();
			Serial.println("Failed to read ID, please make sure all the pins are connected");
			delay(10000);
		}
	}
	Serial.println("Initialising the chip ...");
	max30003.max30003Begin(); // initialize MAX30003
}

void accel_LIS2DH12_Init(void)
{
	Serial.println("SparkFun Accel Example");
	Wire.begin(21, 22, 400000); // 初始化I2C总线，SDA=21, SCL=22, 400kHz
	if (accel.begin() == false)
	{
		Serial.println("Accelerometer not detected. Check address jumper and wiring. Freezing...");
		while (1);
	}
}

// Max30003
void xTaskOne(void *xTask)
{
	sys_event_t sys_event;
	float ecg_samples[32]; // 直接存储浮点数
	while (1)
	{
		for(int i=0; i<32; i++)
		{
			max30003.getEcgSamples();
			ecg_samples[i] = max30003.ecgdata;
		}
		usr_ble_ecg_data_send((uint8_t*)ecg_samples, sizeof(ecg_samples));
		vTaskDelay(pdMS_TO_TICKS(5)); // 非阻塞，释放CPU给其他任务
	}
}
// LIS2DH12
#define ACC_NUM  20
uint16_t acc_index = 0;
static void xTaskTwo(void *xTask)
{
	sys_event_t sys_event;
	float sendBuf[3 * ACC_NUM];
	while (1)
	{
		if (accel.available())
		{
			sendBuf[acc_index++] = accel.getX();
			sendBuf[acc_index++] = accel.getY();
			sendBuf[acc_index++] = accel.getZ();
			Serial.printf("accx:%.2f,accy:%.2f,accz:%.2f\r\n", sendBuf[acc_index-3], sendBuf[acc_index-2], sendBuf[acc_index-1]);
			if(acc_index >= 3 * ACC_NUM){
				usr_ble_acc_data_send((uint8_t*)sendBuf, sizeof(sendBuf));
				acc_index = 0;
			}
		}
		vTaskDelay(pdMS_TO_TICKS(1)); // 非阻塞，释放CPU给其他任务
	}
}

// 处理消息队列
static void xTaskThree(void *xTask)
{
	sys_queue = xQueueCreate(120, sizeof(sys_event_t));
	static sys_event_t event;
	float sendECG[32];
	uint16_t ecg_calculate_index = 0;
	boolean hr_calculate_flag = false;//计算心率标志位
	char buffer[128]; // 128 字节足够
	while(1)
	{
 		if(xQueueReceive(sys_queue, (void *)&event, (TickType_t)(portMAX_DELAY)))
        {
        	switch(event.type)
        	{
        		case BLE_SEND_ECG_DATA:
        		{
					for(int i = 0; i<(event.size/4); i++) 
					{
						float ecg = 0;
						memcpy(&ecg, &event.ecgdata[4*i], 4); // 复制 4 字节到 float
						// float dECG = filter(ecg);

						float dECG = filter0(ecg);
                    	dECG = filter1(dECG);
                    	dECG = filter2(dECG);	
						sendECG[i] = -ecg;
					}
					pTxCharacteristic->setValue((uint8_t*)&sendECG, event.size);
					pTxCharacteristic->notify();

					sys_event_t sys_event;
					sys_event.type = BLE_SEND_HR_DATA;
					sys_event.size = 32;
					sys_event.Fdata = sendECG;
					task_message_send(sys_event);
        		}break;
				case BLE_SEND_HR_DATA:
				{
					for(uint8_t i=0; i<event.size; i++){
						calculator.addData(event.Fdata[i], resp_sample_index++);	
						ecg_calculate_index++;
 						if(ecg_calculate_index == 2*256){
                        	ecg_calculate_index = 0;
                       		hr_calculate_flag = true;
                    	}
					}
					if(hr_calculate_flag==true)
					{
						hr_calculate_flag = false;
						std::stringstream ss;
						std::string buf;
						uint32_t calibrated_hr = HeartRateCalibrator_calibrate(calibrator, calculator.getHeartRate());
						uint32_t calibrated_resp = calculator.getRespiratoryRate();
    					ss << "hr:" << calibrated_hr << ",resp:" << calibrated_resp;
    					buf = ss.str();
					
						pTxCharacteristic_2->setValue((uint8_t*)buf.c_str(), buf.length());
						pTxCharacteristic_2->notify();
					}
				}break;
				case BLE_SEND_ACC_DATA:
        		{
					pTxCharacteristic_2->setValue(event.ecgdata, event.size);
					pTxCharacteristic_2->notify();
        		}break;
        	}
        }
		vTaskDelay(pdMS_TO_TICKS(1)); // 非阻塞，释放CPU给其他任务
	}
}

#define  LED_PIN  27
uint8_t led_state = 0;
void InitLed()
{
	  // 初始化 GPIO27 为输出模式
	  pinMode(LED_PIN, OUTPUT);
	  // 设置 GPIO27 为低电平
	  digitalWrite(LED_PIN, led_state);
}
void toggleLed()
{
	led_state = !led_state;
	digitalWrite(LED_PIN, led_state);
}

void setup()
{
	Serial.begin(115200);
	// 初始化MAX30003、LIS2DH12加速度计、BLE、LED和按钮
	max30003_Init();
	accel_LIS2DH12_Init();
	BLE_Init();
	InitLed();
}

TimerHandle_t timer_100ms;
#define TIMER_PERIOD_100MS      pdMS_TO_TICKS(100)

static void timer_100ms_handle(TimerHandle_t xTimer)
{
    static uint32_t cnt = 0;
	cnt++;
	if(cnt%10 == 0)//10s采集一次心率和温度
	{
		toggleLed();
		cnt = 0;
	}
}

void loop()
{
	timer_100ms = xTimerCreate("TIMER_10HZ", TIMER_PERIOD_100MS, pdTRUE, NULL, timer_100ms_handle);
    xTimerStart(timer_100ms, 0);

	xTaskCreate(
		xTaskOne,  /* Task function. */
		"TaskOne", /* String with name of task. */
		4096,	   /* Stack size in bytes. */
		NULL,	   /* Parameter passed as input of the task */
		6,		   /* Priority of the task.(configMAX_PRIORITIES - 1 being the highest, and 0 being the lowest.) */
		NULL);	   /* Task handle. */

	xTaskCreate(
		xTaskTwo,  /* Task function. */
		"TaskTwo", /* String with name of task. */
		4096,	   /* Stack size in bytes. */
		NULL,	   /* Parameter passed as input of the task */
		6,		   /* Priority of the task.(configMAX_PRIORITIES - 1 being the highest, and 0 being the lowest.) */
		NULL);	   /* Task handle. */

	xTaskCreate(
		xTaskThree,  /* Task function. */
		"TaskThree", /* String with name of task. */
		2048*4,	   /* Stack size in bytes. */
		NULL,	   /* Parameter passed as input of the task */
		6,		   /* Priority of the task.(configMAX_PRIORITIES - 1 being the highest, and 0 being the lowest.) */
		NULL);	   /* Task handle. */

	while (1)
	{
		BLE_Connection_Status();
	}
}

/*****************************************************************************/
void task_message_send(sys_event_t event)
{
	// 尝试获取互斥锁（10ms超时）
    if (xSemaphoreTake(MuxSem_Handle, pdMS_TO_TICKS(10)) == pdTRUE) {
        if (sys_queue != NULL) {
            // 根据队列剩余空间动态调整等待时间
			myUBaseType = uxQueueSpacesAvailable(sys_queue);
            TickType_t waitTime = (myUBaseType > 5) ? 0 : pdMS_TO_TICKS(5);
			//asyncPrint("spaces: %d, wait time: %d ms", myUBaseType, waitTime);
            if (xQueueSend(sys_queue, &event, waitTime) != pdTRUE) {
                // 记录发送失败（可统计丢包率或触发错误处理）
                Serial.printf("Queue full, event dropped!");
            }
        }
        xSemaphoreGive(MuxSem_Handle);
    } else {
        // 记录锁获取失败
        Serial.printf("Mutex timeout!");
    }
}

void usr_ble_ecg_data_send(uint8_t* ecgdata, uint16_t size)
{
	usr_ecg_event.type = BLE_SEND_ECG_DATA;
	usr_ecg_event.ecgdata = ecgdata;
	usr_ecg_event.size = size;
	task_message_send(usr_ecg_event);
}

void usr_ble_acc_data_send(uint8_t* fdata,uint16_t size)
{
	usr_acc_event.type = BLE_SEND_ACC_DATA;
	usr_acc_event.ecgdata = fdata;
	usr_acc_event.size = size;
	task_message_send(usr_acc_event);
}
